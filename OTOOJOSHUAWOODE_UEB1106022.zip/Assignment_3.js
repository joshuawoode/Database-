// MongoDB version of users collection and queries

db.createCollection("users");

db.users.insertOne({
  first_name: "hjdk",
  last_name: "yode",
  email: "ynsgmail.com",
  phone: "0244368960",
  gender: "female",
  country: "ghana"
});

db.users.find();
