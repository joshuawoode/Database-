insert into users(first_name,last_name,email, phone,gender,country)
values
( 'hjdk', 'yode', 'ynsgmail.com', '0244368960', 'female', 'ghana');

SELECT * FROM musicclass.users;